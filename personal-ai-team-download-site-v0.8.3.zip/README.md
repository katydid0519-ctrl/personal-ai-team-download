# Personal AI Team 다운로드 페이지

이 저장소는 **Netlify에 연결할 공개 정적 다운로드 페이지**와 공개 릴리스만 담습니다. 실제 앱 소스 저장소와 사용자 데이터는 포함하지 않습니다.

## Netlify 연결

1. Netlify에서 **Add new project** → **Import an existing project**를 선택합니다.
2. GitHub 저장소 `katydid0519-ctrl/personal-ai-team-download`을 선택합니다.
3. Build command는 비워 두고, Publish directory는 `.`로 둡니다.
4. Deploy를 누르면 발급된 Netlify 주소가 이 다운로드 페이지의 공유 링크가 됩니다.

설치 파일은 Netlify가 아니라 GitHub Releases에서 제공됩니다. 대용량 Windows 설치 파일을 정적 사이트 배포에 포함하지 않고, 페이지의 두 다운로드 버튼이 해당 공개 릴리스 파일로 연결됩니다.

## 배포 파일

- 설치형: `Personal-AI-Team-Setup-0.8.3.exe`
- 포터블: `Personal-AI-Team-0.8.3.exe`
- 파일 무결성 확인: 릴리스의 `SHA256SUMS-0.8.3.txt`
